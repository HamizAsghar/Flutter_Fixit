class Supabaseconfig {
  static const String supaBaseURL = 'https://tjtcwhseiqzboibioygf.supabase.co';
  static const String supaBaseAnon = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRqdGN3aHNlaXF6Ym9pYmlveWdmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjczNTU0NjgsImV4cCI6MjA4MjkzMTQ2OH0.N3jRG7RS9mth0Jhrmeitf1_ikSq1SAkMd1LRhwtjNyE';
}
